from rest_framework.response import Response
from rest_framework.views import APIView
from . import models
from . import serializers
from django.forms.models import model_to_dict
# from PIL import Image

# Create your views here.

# class People(APIView):
#     def get(self, request):
#         lst_people_in_dict_type = []
#         peoples = models.People.objects.all()
#         # for people in peoples:

#         #     people_in_dict = model_to_dict(people)
#         #     lst_people_in_dict_type.append(people_in_dict)

        
#         _key = list(models.People.objects.model.__dict__.keys())
#         for i in range(6):
#             _key.pop(0)
        
#         _key.pop(-1)
#         _key.pop(-1)
        
#         people_list = list(models.People.objects.values())
#         print(_key)
#         def make_response(objects):
#             res_dict = {}

#             for people_ in objects:
#                 if res_dict != {}:
#                     lst_people_in_dict_type.append(res_dict)
#                     res_dict = {}
#                 del people_['id']
#                 # print(people_)
#                 for i in _key :
#                     if i == "img":
#                         res_dict[i]=f"media/{people_[i]}"
#                     else:
#                         res_dict[i]=people_[i]
#                     # media\scorpion.png


        
                

                
#         make_response(people_list)
#         return Response(lst_people_in_dict_type)
        
            
        #     # lst_people_in_dict_type.append(people.__dict__)/
        #     x = {
        #         'name':people.name,
        #         'last name':people.last_name,
        #         'national_id':people.national_id,
        #         'city':people.city,
        #         'job':people.job,
        #         'is live':people.is_live,
        #         'birth date':people.birth_date.strftime('%m/%d/%Y'),
        #         'image':people.picture.url
        #         }
        #     lst_people_in_dict_type.append(x)
        

#     def post(self, request):
        
#         name = request.data['name']
#         last_name = request.data['last_name']
#         national_id = request.data['national_id']
#         city= request.data['city']
#         job = request.data['job']
#         is_live = request.data['is_live']
#         new_obj = models.People.objects.create(name=name,last_name=last_name,national_id=national_id,city=city,job=job,is_live=is_live)
        
#         return Response(model_to_dict(new_obj))

#     def put():
#         pass

#     def delete():
#         pass



class People(APIView):
    
    def get(self, request):
        peoples =  models.People.objects.all()
        serialized_people = serializers.People(peoples,many=True)
        return Response(serialized_people.data)





    def post(self, request):
        the_people = serializers.People(data=request.data)
        the_people.is_valid(raise_exception=True)
        the_people.save()
        return Response(the_people.data,status=201)