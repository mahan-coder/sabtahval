from django.db import models

# Create your models here.

class People(models.Model):
    name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    national_id = models.CharField(max_length=100)
    job = models.CharField(max_length=50)
    city = models.CharField(max_length=50)
    is_live = models.BooleanField(default=True)
    # birth_date = models.DateField()
    img = models.ImageField(blank=True)

    def __str__(self) -> str:
        return (f"{self.pk}-{self.name} {self.last_name}")
    