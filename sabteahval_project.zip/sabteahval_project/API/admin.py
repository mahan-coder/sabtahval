from django.contrib import admin
from . import models

# Register your models here.
class AdminApi(admin.ModelAdmin):
    list_display = ['name','last_name','national_id','is_live']

admin.site.register(models.People,AdminApi)