from django.shortcuts import render,HttpResponse
from django.views import generic
from API.models import People

# Create your views here.
def home_page(request):
    if request.method == 'POST':
        
            person =  People.objects.filter(national_id=request.POST['national id'],name=request.POST['name'])
            if list(person) != []:
                context = {}
                for i in person:
                    context['name'] = i.name
                    context['last_name'] = i.last_name
                    context['national_id'] = i.national_id
                    context['job'] = i.job
                    context['city'] = i.city
                    context['is_live'] = i.is_live
            
                return render(request,'home/info.html',context=context)
            else:
                print('00000000000000000000000000000000')
                return render(request,'home/index.html',{'error':'national id or name is incorrect'})

    else:
        return render(request,'home/index.html',context={'error':'hello'})
    

# def info(request):
#         return render(request,'home/info.html')
    