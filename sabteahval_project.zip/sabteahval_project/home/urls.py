from . import views
from django.urls import path,include

urlpatterns = [
    path('', views.home_page,name='home'),
    # path('info/', views.home_page,name='info'),
]